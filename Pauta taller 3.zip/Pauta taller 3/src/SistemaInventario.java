public interface SistemaInventario {

}
