public class InsViento extends Instrumento{
    public InsViento(String material, int stock, String instrumento, int precio, String codigo) {
        super(material, stock, instrumento, precio, codigo);
    }
}
